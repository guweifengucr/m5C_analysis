use strict;
use warnings;

my $min=30;
print "sample names:";
my $sa=<>; chomp $sa;
my @sa=split /\s*\,+\s*/,$sa;

#get transcriptome sequence
my %seq;
&get_seq (\%seq);

#annotate C and the corresponding mutations
foreach my $s (@sa) {
	&add_c ($s.'_all');
}

#annotate C
sub add_c {
	my ($sam)=@_; my $se;
	open (my $fh1,"$sam/$sam\_$min\_cdna_step1.txt") or die $!;
	open (my $fh2,">$sam/$sam\_$min\_cdna_step2.txt");
	while (<$fh1>) {
		$_ =~ s/\s+$//;
		my @a1=split /\t/;
		#get transcrtipt sequence
		if (/^>/) {
			print $fh2 $_,"\n";
			$_ =~ s/^>//;
			$_ =~ s/\tsense$//;
			if (!exists $seq{$_}) {
				print "$_\n";
			}
			$se=$seq{$_};
			next;
		}
		
		#get mutation information
		my %mut;
		if ($a1[5] ne 'N') {
			my @mut=split /\W+/,$a1[5];
			for (my $i=0; $i<$#mut;$i+=2) {
				$mut{$mut[$i]}=$mut[$i+1];
			}
		}

		my $s=substr ($se,$a1[0]-1,$a1[1]+1);
		my $seq=$a1[4];#RNA sequenced
		while ($s =~ /C/g) {
			my $p=pos($s)-1;
			my $nt=substr($seq,$p,1);
			$nt =~ tr/ACGT/acgt/;
			my $ont=substr $seq,$p,1,$nt; #convert nts matching C to lc on reads
			if (exists $mut{$p}) {
				my $m=$mut{$p};
				$m =~ tr/ACGT/acgt/;
				$mut{$p}=$m;#convert nts matching C to lc on mutation
			}
		}
		my $m='N';
		if ($a1[5] ne 'N') {
			$m='';
			foreach my $mp (sort {$a<=>$b} keys %mut) {
				$m.=$mp.':'.$mut{$mp}.',';
			}
			$m =~ s/\,$//;
		}
		print $fh2 "$a1[0]\t$a1[1]\t$a1[2]\t$a1[3]\t$seq\t$m\n";
	}
}

#get transcriptome sequence
sub get_seq {
	my ($seq)=@_;
	open (my $fh1,"HSGRCH3771_cdna_seq_final_no100.txt") or die $!;
	while (<$fh1>) {
		$_ =~ s/\s+$//;
		$_ =~ s/^>//;
		my ($id,$se)=split /\|/;
		${$seq}{$id}=$se;
	}
	close $fh1;
}		
