use strict;
use warnings;
print "sample name:";
my $sample=<>; chomp $sample;
my @sam=split /\s*\,+\s*/,$sample;
my $min=30;
foreach my $s (@sam) {
	&analyze_mut ($s);
}

sub analyze_mut {
	my ($sam)=@_;

	open (hand1,"$sam\_all/$sam\_all_30_cdna_step2.txt") or die $!;
	my %sr; my $gr; my %mt;
	while (<hand1>) {
		$_ =~ s/\s+$//;
		my @a1=split /\t/;
		if (/^>/) {
			$gr=$a1[4];
			next;
		}
		$sr{$gr}{$a1[4]}=$a1[2];
		$mt{$gr}{"$a1[4]\t$a1[2]"}{$a1[5]}=1;
	}
	close hand1;

	open (hand1,">$sam\_all/sum_$sam\_all_size_step3a.txt");
	foreach my $gr (sort {$a cmp $b} keys %sr) {
		print hand1 ">$gr\n"; my %si;
		foreach my $re (sort {$a cmp $b} keys %{$sr{$gr}}) {
			$si{length($re)}+=$sr{$gr}{$re};
		}
		foreach my $si (sort {$a<=>$b} keys %si) {
			print hand1 "$si\t$si{$si}\n";
		}
	}
	close hand1;

	open (hand1,">$sam\_all/sum_$sam\_all_mutations_step3b.txt");
	my %qua; &get_quality ($sam,\%qua);

	foreach my $gr (sort {$a cmp $b} keys %mt) {
		print hand1 ">$gr\n"; my %m;
		foreach my $reno (sort {$a cmp $b} keys %{$mt{$gr}}) {
			my ($re,$no)=split /\t/,$reno;
			my $r=$re; $r =~ tr/acgt/ACGT/;
			my $hit=scalar keys %{$mt{$gr}{$reno}};
			next if $hit >1; my %mpos; my %re;
			print "wrong read no $re $no\n" if $#{$qua{$r}}+1 !=$no;

			foreach my $qua (@{$qua{$r}}) {
				my ($q1,$q2)=split /\t/,$qua;
				my $q3=substr(dec2bin($q1),-25);
				my $q4=substr(dec2bin($q2),25-length($r));
				my $q=$q3.$q4;
				for (my $i=0; $i<length($q); $i++) {
					if (substr ($q,$i,1) ==1) {
						$re{$i}++;
					}
					else {
						$re{$i}+=0;
					}
				}
			}

			foreach  my $mt (keys %{$mt{$gr}{$reno}}) {
				next if $mt eq 'N';
				my @mt=split /\,|\:/,$mt;
				for (my $i=0; $i<$#mt; $i+=2) {
					$m{$mt[$i]}{$mt[$i+1]}+=$re{$i};
					$mpos{$mt[$i]}=1;
				}
			}#calculte at mutation position
			for (my $i=0; $i<length($re); $i++) {
				next if exists $mpos{$i};#calculated already
				my $nt=substr ($re,$i,1);
				$m{$i}{$nt.$nt}+=$re{$i};
			}
		}#add perfect matches

		foreach my $p (sort {$a<=>$b} keys %m) {
			print hand1 $p+1;
			foreach my $ty (sort {$b cmp $a} keys %{$m{$p}}) {
				my $r=int($m{$p}{$ty}+0.5);
				print hand1 "\t$ty\t$r";
			}
			print hand1 "\n";
		}
	}
	close hand1;
}

sub get_quality {
	my ($sa,$qua)=@_; my $line; my $seq;
	my $rec=`tar -xvzf fastaq/$sa/$sa\_raw.fastq.tar.gz`;
	open (my $fh1,"fastaq/$sa/$sa\_raw.fastq") or die $!;	
	while (<$fh1>) {
		$_ =~ s/\s+$//;
		$line++; my $res=$line % 4;
		next if $res ==1 || $res ==3;
		$seq=$_ if $res==2;
		if ($res ==0) {
			if ($seq =~ /^(.*)AGATCGGAA/) {
				$seq =$1;
			}
			else {
				$seq =~ s/(AGATCGGA|AGATCGG|AGATCG|AGATC|AGAT|AGA|AG)$//;
			}
			next unless length($seq) >=$min && $seq !~ /(\.|N)/; #follows the same rule as step1

			$_ =~ s/(\#|-|7|<)/0/g;
			$_ =~ s/(A|F|J)/1/g;
			my $q1=bin2dec (substr ($_,0,25));
			my $q2=bin2dec (substr ($_,25,length($seq)-25));
			push @{${$qua}{$seq}},"$q1\t$q2";
		}
	}
	close $fh1;
	$rec=`rm fastaq/$sa/$sa\_raw.fastq`;
}

sub dec2bin {
    my $str = unpack("B32", pack("N", shift));
    return $str;
}

sub bin2dec {
    return unpack("N", pack("B32", substr("0" x 32 . shift, -32)));
}
