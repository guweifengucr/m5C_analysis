use strict;
use warnings;
my $min=30;
print "sample name:";
my $sam=<>; chomp $sam;
my @sam=split /\s*\,+\s*/,$sam;

foreach my $s (@sam) {
	&analyze_gene ($s.'_all');
}

sub analyze_gene {
	my ($sa)=@_; my %t; my $on=0; my $type='protein';
	open (my $fh1,"$sa/$sa\_$min\_cdna_step2.txt") or  die $!;
	open (my $fh2,">$sa/$sa\_$min\_cdna_$type\_step4a.txt");
	while (<$fh1>) {
		my @a1=split /\t/;
		if (/^>/) {
			$on=0;
			if ($a1[4] eq $type) {
				$on=1;
				print $fh2 $_;
			}
			next;
		}
		next if $on ==0;
		print $fh2 $_;
	}
	close $fh1; close $fh2;

	open ($fh1,"$sa/$sa\_$min\_cdna_$type\_step4a.txt");
	open ($fh2,">$sa/$sa\_$min\_cdna_$type\_step4b.txt");
	open (my $fh3,">$sa/$sa\_$min\_cdna_$type\_step4c.txt");
	while (<$fh1>) {
		$_ =~ s/\s+$//;
		my @a1=split /\t/;

		if (/^>/) {
			my %sum;
			foreach my $p (sort {$a <=> $b} keys %t) {
				print $fh2 $p;
				foreach my $mt (sort {$a cmp $b} keys %{$t{$p}}) {
					print $fh2 "\t$mt\t$t{$p}{$mt}";
					$sum{$mt}+=$t{$p}{$mt};
				}
				print $fh2 "\n";
			}
			foreach my $mt (sort {$a cmp $b} keys %sum) {
				print $fh3 "\t$mt\t$sum{$mt}";
			}
			print $fh3 "\n";
			print $fh3 "$a1[1]\t$a1[2]";
			print $fh2 ">$a1[1]\t$a1[2]\n";
			%t=();
			next;
		}

		my $seq=$a1[4];
		while ($seq =~ /(a|c|g|t)/g) {
			$t{pos($seq)+$a1[0]-1}{'tt'}+=0;
			$t{pos($seq)+$a1[0]-1}{'ta'}+=0;
			$t{pos($seq)+$a1[0]-1}{'tg'}+=0;
			$t{pos($seq)+$a1[0]-1}{'tc'}+=0;
			$t{pos($seq)+$a1[0]-1}{'t'.$1}+=$a1[2];
		}
	}

	my %sum;
	foreach my $p (sort {$a <=> $b} keys %t) {
		print $fh2 $p;
		foreach my $mt (sort {$a cmp $b} keys %{$t{$p}}) {
			print $fh2 "\t$mt\t$t{$p}{$mt}";
			$sum{$mt}+=$t{$p}{$mt};
		}
		print $fh2 "\n";
	}
	foreach my $mt (sort {$a cmp $b} keys %sum) {
		print $fh3 "\t$mt\t$sum{$mt}";
	}
	print $fh3 "\n";
	close $fh1; close $fh2; close $fh3;
}
