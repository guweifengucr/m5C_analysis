use strict;
use warnings;
####the position coor refers to watson from small to big
#the end or the middle coors refer to start (base 0)
#the mutation pos refers to the start on watson (base 0)
#the mutation refers to RNA seq (not watson) for convenience

my $min=30;
print "sample name:";
my $s=<>; chomp $s;
my @sa=split /\s*\,\s*/, $s;
foreach my $sam (@sa) {
	&fix_coordinate ($sam.'_all');
}

####
sub fix_coordinate {
	my ($sam)=@_; my %gp; &get_transcript_pos (\%gp);
	my %ttoc; my $ch; my $type; my $sr; my %hit;
	open (my $fh1,"$sam/$sam\_$min\_cdna_step2.txt") or die $!;
	open (my $fh2,">$sam/$sam\_$min\_cdna_step5temp.txt");
	while (<$fh1>) {
		$_ =~ s/\s+$//;
		my @a1=split /\t/;
		if (/^>/) {
			print $fh2 $_,"\n";
			%ttoc=(); $ch=$a1[5]; $sr=$a1[6]; $type=$a1[9];
			$_ =~ s/\t(sense|anti)$//; $_ =~ s/^>//;
			if ($type eq 'anti') {
				print $_,"\n";
				$sr =~ tr/\+-/-\+/;
			}
			&convert_pos($gp{$_},$sr,\%ttoc);
		}
		else {
			my @expo;
			for my $p ($a1[0]..$a1[0]+$a1[1]) {
				push @expo, $ttoc{$p};
			}
			my $sten=fix_exex (\@expo); my $mt='N';
			if ($a1[5] ne 'N') {
				$mt='';
				my @mt=split /\W+/,$a1[5];				
				for (my $i=0; $i<$#mt; $i+=2) {
					my $mtpo=$ttoc{$mt[$i]+$a1[0]}-$ttoc{$a1[0]};
					if ($sr eq '-') {
						$mtpo=$ttoc{$mt[$i]+$a1[0]}-$ttoc{$a1[0]+$a1[1]};
					}
					$mt.=$mtpo.':'.$mt[$i+1].',';
				}
				$mt =~ s/\,$//;
			}
			print $fh2 "$ch\t$sr\t$sten\t$a1[2]\t$a1[3]\t$a1[4]\t$mt\n";#mt position refer to the first No. in $sten
			$hit{$a1[3]}{"$ch\t$sr\t$sten"}=1;
		}
	}
	close $fh1; close $fh2;
	
	#assume for each "$ch\t$sr\$sten", the read only has one way to match
	open ($fh1,"$sam/$sam\_$min\_cdna_step5temp.txt");
	open ($fh2,">$sam/$sam\_$min\_cdna_step5.txt");
	while (<$fh1>) {
		if (/^>/) {
			print $fh2 $_;
		}
		else {
			my @a1=split /\t/; my $hit=scalar keys %{$hit{$a1[4]}};
			print $fh2 "$a1[0]\t$a1[1]\t$a1[2]\t$a1[3]\t$hit\t$a1[4]\t$a1[5]\t$a1[6]";
		}
	}
	close $fh1; close $fh2;
	my $rec=`rm $sam/$sam\_$min\_cdna_step5temp.txt`;
}

####get all transcript exons
#no100 means this is the annotated sequence
sub get_transcript_pos {
	my ($gp)=@_;
	open (my $fh1,"HSGRCH3771_cdna_pos_final_no100.txt") or die $!;
	while (<$fh1>) {
		$_ =~ s/\s+$//;
		my ($id,$po)=split /\|/;
		${$gp}{$id}=$po;	
	}
	close $fh1;
}

#### key for transcript pos and value for chromosome pos
#refer to watson (if on crick, complement the nt), transcript pos (base 1) vs chromosome position (base 1)
#consecutive cDNA coordinates vs non-consecutive genomic coordinates
sub convert_pos {
	my ($po,$sr,$ttoc)=@_; my $c=0;
	my @po=split /\D+/,$po; @po=sort {$a <=> $b} @po; 
	for (my $i=0; $i<$#po; $i+=2) {
		foreach my $p ($po[$i]..$po[$i+1]) {
			$c++; ${$ttoc}{$c}=$p;
		}
	}

	if ($sr eq '-') {
		my %anti;
		foreach my $p (keys %{$ttoc}) {
			$anti{$c-$p+1}=${$ttoc}{$p};
		}
		%{$ttoc}=%anti;
	}
}

####fix exex coordinate (group into exons)
#just provide every nt position on watson strand
#refer to the start (+ gene) or end site (- gene) on watson strand
#basically refer to the smallest nt position
#from small to big regardless of the strand
sub fix_exex {
	my ($expo)=@_; my @ep= sort {$a <=> $b} @{$expo}; my $exex;
	$exex.=$ep[0];
	for (my $i=0; $i<$#ep; $i++) {
		if ($ep[$i+1]-$ep[$i] >1) {
			my $r=$ep[$i]-$ep[0];
			my $l=$ep[$i+1]-$ep[0];
			$exex.='-'.$r.'_'.$l;
		}
	}
	my $last=$ep[-1]-$ep[0];
	$exex.='-'.$last;
	return $exex; 
}
