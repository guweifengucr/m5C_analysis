use strict;
use warnings;

#for tc sites, ignore repeats >10 times
#no normalization
#no repeat normalization
#ignore ta>tc; tg>tc
#remove reads containing 50% or more nonconverted C's
my $min=30;
my $reno=10;
print "sample name:";
my $s=<>; chomp $s;
my @sa=split /\s*\,\s*/, $s;
foreach my $sam (@sa) {
	&sum_tc ($sam.'_all');
}


sub sum_tc {
	my ($sam)=@_;
	open (my $fh1,"$sam/$sam\_$min\_cdna_step5.txt") or die $!;
	my %tc; my %tt; my %gene; my $gene; my $trans; my $tot; my %counted;#use a filter to count only once reads matching multiple transcripts
	while (<$fh1>) {
		$_ =~ s/\s+$//;
		my @a1=split /\t/;
		if (/^>/) {
			$gene=$a1[1]; $trans=$a1[2];
			next;
		}

		if (!exists $counted{"$a1[0]\t$a1[1]\t$a1[2]\t$a1[5]"}) {
			$tot+=$a1[3]/$a1[4];
		}
		next if $a1[4] >10 && $trans !~ /rRNA45SN/;#remove reads matching at least 10 genomic loci for non-rRNA
		next if $a1[4] >50 && $trans =~ /rRNA45SN/;#remove reads matching at least 50 genomic loci for rRNA

		#### remove reads containing too many nonconverted C's
		if ($a1[7] =~ /c/) {
			my $t=0; my $c=0;
			while ($a1[6] =~ /(a|c|g|t)/g) {
				$t++;
				if ($1 eq 'c') {
					$c++;
				}
			}	
			next if $c/$t >=0.5;
		}

		####chr positions
		my @po=split /\D+/,$a1[2]; my @p;
		for (my $i=0; $i<$#po; $i+=2) {
			my $st=$po[$i]; my $en=$po[$i+1]+$po[0];
			if ($i >0) {
				$st+=$po[0];
			}
			for my $p ($st..$en) {
				push @p,$p;
			}
		}

		my $rna=$a1[6]; $rna=reverse $rna if $a1[1] eq '-'; #only reverse so the rna nt is still derived from crick but coordinate is from watson
		for (my $i=0; $i <length($rna); $i++) {
			next unless substr ($rna,$i,1) =~ /[acgt]/;#C nt
			my $mp=$p[$i];
			$tt{"$a1[0]\t$a1[1]\t$mp"}+=$a1[3] if !exists $counted{"$a1[0]\t$a1[1]\t$a1[2]\t$a1[5]"};
			$gene{"$a1[0]\t$a1[1]\t$mp"}{$gene}{$trans}=1; #no the above condition
		}

		if ($a1[7] ne 'N') {
			my @mt=split /\W+/,$a1[7];
			for (my $i=0; $i<$#mt; $i+=2) {
				next unless $mt[$i+1] =~ /^t/;
				my $mp=$mt[$i]+$p[0];
				$tc{"$a1[0]\t$a1[1]\t$mp"}{$mt[$i+1]}+=$a1[3] if !exists $counted{"$a1[0]\t$a1[1]\t$a1[2]\t$a1[5]"};
			}
		}

		$counted{"$a1[0]\t$a1[1]\t$a1[2]\t$a1[5]"}=1;
	}
	close $fh1;
	my $ratio=1;# ignore this anyway since there is no normalization

	open ($fh1,">$sam/$sam\_$min\_cdna_$reno\_step6.2.txt");
	foreach my $loci (sort {$a cmp $b} keys %tt) {
		next if $tt{$loci} < $reno;
		my $tc=0;
		if (exists $tc{$loci}{'tc'}) {
			$tc=$tc{$loci}{'tc'};
		}
		next if exists $tc{$loci}{'ta'} && $tc{$loci}{'ta'} >=$tc;
		next if exists $tc{$loci}{'tg'} && $tc{$loci}{'tg'} >=$tc;
		my $tt=$tt{$loci};
		print $fh1 "$loci\t$tc\t$tt\t";
		foreach my $gene (sort {$a cmp $b} keys %{$gene{$loci}}) {
			print $fh1 "$gene\(";
			my $trans;
			foreach my $tr (sort {$a cmp $b} keys %{$gene{$loci}{$gene}}) {
				$trans.=$tr.',';
			}
			$trans =~ s/\,$/\)\;/;
			print $fh1 $trans;
		}
		print $fh1 "\n";
	}
	close $fh1;
}
